# bootgrid-php-mysql-serverside-code
Add,Edit and Delete Record using Bootgrid , PHP and MySQL
